/*
 ============================================================================
 Name        : PcvsPc.c
 Author      : Martin Monzon, Jorge Estigarribia
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#define NLEN 100
/*
Probablemente la funcion sea void,
ahora debemos utilizar nuestras funciones para sobreescribir el archivo de texto
*/
int main(void)
{
	char *name1,*name2;
	name1=(char*)malloc(NLEN);
	name2=(char*)malloc(NLEN);
	printf("Ingrese el nombre del jugador 1: ");
	scanf("%s",name1);
	printf("Ingrese el nombre del jugador 2: ");
	scanf("%s",name2);
//	printf("%s %s",name1,name2);
	FILE *NM1 = NULL;
	FILE *NM2 = NULL;
	NM1 = fopen("NM1.txt" ,"w");
	NM2 = fopen("NM2.txt" ,"w");
	fprintf(NM1,"%s",name1);
	fprintf(NM2,"%s",name2);
	free(name1);
	free(name2);
	fclose(NM1);
	fclose(NM2);
	return 1;
}

